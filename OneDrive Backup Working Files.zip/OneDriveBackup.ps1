# Define log files
$TranscriptFile = "D:\TaskDebugLog.txt"  # Full execution transcript
$ErrorLogFile = "D:\BackupErrorLog.txt"  # Errors and additional log messages

# Start transcript to capture the full output
Start-Transcript -Path $TranscriptFile -Append

try {
    # Log the start of the backup
    Add-Content -Path $ErrorLogFile -Value "Backup process started at $(Get-Date)"

    # Define paths
    $SourcePath = "C:\Users\aggar\OneDrive\*"  # Source directory
    $DestinationPath = "D:\OneDriveBackup_from_C_to_D"  # Destination directory

    # Ensure the destination directory exists
    if (!(Test-Path -Path $DestinationPath)) {
        Add-Content -Path $ErrorLogFile -Value "Destination directory does not exist. Creating it..."
        New-Item -ItemType Directory -Path $DestinationPath | Out-Null
    }

    # Start a continuous monitoring loop
    while ($true) {
        try {
            # Perform the backup with advanced handling for locked files
            Get-ChildItem -Path $SourcePath -Recurse | ForEach-Object {
                try {
                    # Attempt to copy the file/directory
                    $Destination = Join-Path -Path $DestinationPath -ChildPath $_.FullName.Substring($SourcePath.TrimEnd('\*').Length)
                    if ($_ -is [System.IO.DirectoryInfo]) {
                        # Create directories as needed
                        if (!(Test-Path -Path $Destination)) {
                            New-Item -ItemType Directory -Path $Destination | Out-Null
                        }
                    } else {
                        # Copy files
                        Copy-Item -Path $_.FullName -Destination $Destination -Force -ErrorAction Stop
                    }
                } catch {
                    # Log any locked files or errors
                    Add-Content -Path $ErrorLogFile -Value "Failed to copy $($_.FullName): $($_.Exception.Message)"
                }
            }

            # Log a successful iteration
            Add-Content -Path $ErrorLogFile -Value "Backup iteration completed successfully at $(Get-Date)"
        } catch {
            # Log any global errors during an iteration
            Add-Content -Path $ErrorLogFile -Value "Error occurred during backup iteration: $($_.Exception.Message)"
        }

        # Wait for 1 minute before checking again
        Start-Sleep -Seconds 60
    }
} finally {
    # Stop transcript
    Stop-Transcript
    Add-Content -Path $ErrorLogFile -Value "Backup process finished at $(Get-Date)"
}
