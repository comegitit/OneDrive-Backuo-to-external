# Prompt for credentials
$Credentials = Get-Credential
$UserName = $Credentials.UserName
$Password = $Credentials.GetNetworkCredential().Password

# Scheduled Task Configuration
$TaskName = "OneDriveBackupTask"
$TaskDescription = "Scheduled task to run the PowerShell script for the OneDrive backup."
$PowerShellScriptPath = "D:\OneDriveBackup.ps1"  # Path to the PowerShell script

# Check if the PowerShell script exists
if (!(Test-Path -Path $PowerShellScriptPath)) {
    Write-Host "ERROR: PowerShell script not found at $PowerShellScriptPath."
    exit 1
}

try {
    # Define the action to run the PowerShell script
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$PowerShellScriptPath`""

    # Define the trigger to run the task at user logon
    $Trigger = New-ScheduledTaskTrigger -AtLogon

    # Configure the task settings
    $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -StartWhenAvailable -RestartInterval (New-TimeSpan -Minutes 1) -RestartCount 3

    # Register the task with credentials and elevated privileges
    Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings `
        -User $UserName -Password $Password -RunLevel Highest -Description $TaskDescription -ErrorAction Stop | Out-Null

    Write-Host "Scheduled task '$TaskName' created successfully with retries on failure enabled."
} catch {
    Write-Host "ERROR: Failed to create/update scheduled task: $($_.Exception.Message)"
    exit 1
}
